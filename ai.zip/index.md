# Home - Stroke Dysphagia Care-Transition FHIR IG v1.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://sefatuncer.github.io/stroke-dysphagia-fhir-ig/ImplementationGuide/dysphagia.care.transition | *Version*:1.2.0 |
| Active as of 2026-07-31 | *Computable Name*:DysphagiaCareTransitionIG |
| **Copyright/Legal**: © 2026 N. Kapan Tunçer and S. Tunçer. IG artifacts licensed under the MIT License. This IG carries concept identifiers from SNOMED CT (© SNOMED International), LOINC (© Regenstrief Institute, Inc.) and the IDDSI framework (CC BY-SA 4.0, used unmodified); it redistributes no code system release, national extension or semantic content. Value sets enumerate identifiers, and some members additionally carry the English term as an unmodified display hint; the authoritative display is supplied at expansion time by the implementer's own terminology server. Implementers are responsible for holding the applicable third-party licences. | |

### Stroke Dysphagia Care-Transition FHIR IG

This Implementation Guide defines an **interoperable, machine-readable representation** of swallowing assessment, aspiration risk, dysphagia severity and IDDSI diet/fluid consistency so these data can travel across stroke care transitions (**acute → inpatient rehab → home / tele-rehab**).

> **Scope note (honest framing).** This IG targets **interoperability and computable decision-support feasibility**. It does **not** claim clinical benefit. All examples use **synthetic data only** (no patient data, no ethics approval required).

#### What this IG contributes (the narrow gap)

Diet/IDDSI ordering is already covered by base FHIR `NutritionOrder`, PACIO PFE and SNOMED-embedded IDDSI — this IG **reuses** those rather than re-inventing them. The genuine gap it fills is on the **assessment / outcome / risk** side:

* **Observation profiles** absent from US Core / IPS / PACIO: 
* `SwallowingScreeningResult` (bedside screening — GUSS reuses SNOMED `1289999007`)
* `InstrumentalSwallowAssessment` (VFSS/FEES incl. Penetration-Aspiration Scale)
* `DysphagiaSeverity` (FOIS / DIGEST / IDDSI Functional Diet Scale)
* `AspirationRiskFlag` (patient-level, safety-critical, SNOMED `371736008`)
 
* An **IDDSI Framework `ValueSet`** over SNOMED-embedded IDDSI concepts (no official FHIR ValueSet exists — defining one is a contribution).
* A **`DysphagiaNutritionOrder`** profile that binds IDDSI **extensibly** (base FHIR binds it only as **example**).
* A **`DysphagiaCareTransitionSummary`** Composition — the transfer envelope.
* A set of **validated dysphagia scales that currently lack terminology** (PAS, FOIS, EAT-10, DIGEST, TOR-BSST, Yale residue) captured as temporary local codes and **proposed upstream to LOINC/SNOMED**.

#### Computable decision support (feasibility)

An executable **CQL** rule (`AspirationRiskAlert`) surfaces a care-transition **safety inconsistency** — an at-risk patient still on unmodified (thin, IDDSI Level 0) fluids and not NPO — directly from the profiled data. It compiles to ELM and runs, **unmodified, on a real CQL engine** (cql-execution) over a synthetic Synthea stroke cohort (N = 333). Reported outcomes are **executability**, authoring **concordance**, trigger rate, and — the point — the **interoperability dependency**: clinically-unsafe cases become **invisible to the rule when the aspiration-risk flag is left as un-coded free text** rather than the coded Observation this IG defines. The invisibility rate tracks the un-coded fraction **by construction** (30.0% ± 7.5 percentage points across 40 seeds at P(coded) = 0.70), so it illustrates a mechanism, not an empirical estimate. This is a **feasibility / interoperability** result — **no diagnostic-accuracy or PPV claim**. All data are synthetic.

#### Standards alignment

This IG **extends, does not reinvent**: it declares dependencies on **IPS 2.0.1** and **PACIO PFE 2.0.0** and positions relative to **US Core**. Profiles derive from **base FHIR resources** by design — hard-deriving from these IGs would import mandatory constraints inappropriate for a focused, international dysphagia transfer (IPS Composition requires Problems / Allergies / Medications sections; PACIO's `pfe-nutrition-order` requires `allergyIntolerance` and omits an IDDSI binding). The contribution is precisely the dysphagia-specific gap those frameworks leave open — the **IDDSI binding PACIO omits** and the **assessment / risk profiles IPS and US Core lack**.

#### Status

Released, v1.1.1. Terminology verified against SNOMED CT International 20250201 + LOINC v2.82. Conformance is demonstrated on **two independently deployed servers** — the HL7 reference validator and a containerized HAPI FHIR server — rather than by self-validation alone. Both share the HL7 Java validation core, so this establishes portability across deployments, not independence across implementations. Eight positive examples pass (six against a declared IG profile, two against base FHIR) and **eight negative fixtures are correctly rejected**, each for the specific constraint it violates.

#### Dependencies














#### Intellectual property and terminology licensing

This IG **carries** SNOMED CT, LOINC and IDDSI concept identifiers; it redistributes no code system release, national extension or semantic content (relationships, hierarchies, reference sets). The value sets enumerate identifiers, and a small number of members additionally carry the English term as an unmodified display hint; the authoritative display is supplied at expansion time by the implementer's own terminology server. Identifiers and English terms of this kind fall within SNOMED International's [Global Patient Set](https://www.snomed.org/gps), published at no cost under CC BY-ND 4.0, which does not itself require SNOMED CT membership or an Affiliate Licence. Anyone loading SNOMED CT into a terminology server to expand these value sets is responsible for their own SNOMED CT affiliate/member licensing, as implementers are for the LOINC license and IDDSI's CC BY-SA terms. The MIT license covers only the artifacts authored here and does not relicense any third-party terminology.

This publication includes IP covered under the following statements.

* MIT (© 2026 N. Kapan Tunçer and S. Tunçer). These are locally minted placeholder identifiers only. They name validated instruments whose own copyright rests with their developers; no instrument content, scoring rule or item text is reproduced here. The codes are temporary and are expected to be retired once equivalent concepts exist in LOINC or SNOMED CT.

* [Dysphagia Scales — temporary local codes (proposed for LOINC/SNOMED)](CodeSystem-dysphagia-scales-temp.md): [AspirationRiskFlag](StructureDefinition-aspiration-risk-flag.md), [AspirationRiskValueVS](ValueSet-aspiration-risk-value-vs.md)... Show 8 more, [DysphagiaSeverity](StructureDefinition-dysphagia-severity.md), [DysphagiaSeverityTypeVS](ValueSet-dysphagia-severity-type-vs.md), [InstrumentalSwallowAssessment](StructureDefinition-instrumental-swallow-assessment.md), [InstrumentalSwallowTypeVS](ValueSet-instrumental-swallow-type-vs.md), [Observation/ex-dysphagia-severity](Observation-ex-dysphagia-severity.md), [Observation/ex-instrumental-swallow](Observation-ex-instrumental-swallow.md), [SwallowScreeningTypeVS](ValueSet-swallow-screening-type-vs.md) and [SwallowingScreeningResult](StructureDefinition-swallowing-screening-result.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Composition/ex-care-transition-summary](Composition-ex-care-transition-summary.md), [DysphagiaCareTransitionSummary](StructureDefinition-dysphagia-care-transition-summary.md), [InstrumentalSwallowAssessment](StructureDefinition-instrumental-swallow-assessment.md) and [InstrumentalSwallowTypeVS](ValueSet-instrumental-swallow-type-vs.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AspirationRiskFlag](StructureDefinition-aspiration-risk-flag.md), [AspirationRiskValueVS](ValueSet-aspiration-risk-value-vs.md)... Show 13 more, [DysphagiaNutritionOrder](StructureDefinition-dysphagia-nutrition-order.md), [DysphagiaSeverity](StructureDefinition-dysphagia-severity.md), [DysphagiaSeverityTypeVS](ValueSet-dysphagia-severity-type-vs.md), [IDDSIFluidLevels](ValueSet-iddsi-fluid-levels.md), [IDDSIFoodLevels](ValueSet-iddsi-food-levels.md), [InstrumentalSwallowAssessment](StructureDefinition-instrumental-swallow-assessment.md), [InstrumentalSwallowTypeVS](ValueSet-instrumental-swallow-type-vs.md), [NutritionOrder/ex-dysphagia-diet](NutritionOrder-ex-dysphagia-diet.md), [Observation/ex-aspiration-risk](Observation-ex-aspiration-risk.md), [Observation/ex-instrumental-swallow](Observation-ex-instrumental-swallow.md), [Observation/ex-swallow-screening](Observation-ex-swallow-screening.md), [SwallowScreeningTypeVS](ValueSet-swallow-screening-type-vs.md) and [SwallowingScreeningResult](StructureDefinition-swallowing-screening-result.md)


